const form = document.querySelector('form');
const divResultado = document.querySelector('#resultado');
const scriptTemplate = document.querySelector('#template');
const erroAlert = document.getElementById('erroAlert');
form.addEventListener('submit', function(e) {
  busca(form.cep.value);
  e.preventDefault();
});

// Gets 'cep' by what is containet in the parentheses of the line 5
function busca(cep) { // cep: 96201460
  const url = `http://viacep.com.br/ws/${cep}/json/`;
  ajax(url, function(e) {
// e.target-> refers to the cep sent to the API server
// e.target.response -> returns the response sent by the 
// API server once accepted the CEP's information request
// The line below 
// printa(JSON.parse(e.target.response));
  let erro = JSON.parse(e.target.response);
  
  if (erro.erro === undefined) {// If there is no error
    printa(JSON.parse(e.target.response));// Then, show the result
    erroAlert.style = "display:none";//And set the error alert as hidden
    divResultado.style = '';// and show the rusults div
    } else {//Either
      erroAlert.style = '';//set the error alert as showed
      divResultado.style = 'display:none'; 
    }
  });
}

// Gets by 'url' whats is contained in the respective 
// place in the 12th line and by 'callback' 
// what is returned by the funtion 'printa'
function ajax(url, callback) {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.onload = callback;
  xhr.send();
}

function printa(json) {
  // Gets the sintax of the script obtained in the line 3
  const template = scriptTemplate.innerText;
  // Handlebars.compile() makes the data setted in JS file be tranfered to the mustaches in the scripted HTML
  const handlebars = Handlebars.compile(template);
  const html = handlebars(json);
  divResultado.innerHTML = html;
} 

form.addEventListener('keydown', function(e) {
  
});
const input = document.querySelector('input');
input.addEventListener('keydown', function(e) {  
  let l = e.target.value.length;
  if (l>=8) { 
    if (!((e.key==='Backspace')||(e.key==='ArrowLeft')||(e.key==='ArrowRight')||(e.key==='Delete'))) {
      e.preventDefault();
    }
  }
  let key = parseInt(e.key);
  if (!((key>=0 && key<=9)||(e.key==='ArrowLeft')||(e.key==='ArrowRight')||(e.key==='Backspace')||(e.key==='Delete'))) {
    e.preventDefault();
  }
});
